﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Animals
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Animal> animals = new List<Animal>();

            string inputLine1 = "";
            while ((inputLine1 = Console.ReadLine()) != "Beast!")
            {
                List<string> inputLine2 = Console.ReadLine().Split().ToList();

                if (int.Parse(inputLine2[1]) < 0 || (inputLine2[2] != "Male" && inputLine2[2] != "Female"))
                {
                    Console.WriteLine("Invalid input!");
                    continue;
                }
                switch (inputLine1)
                {
                    case "Cat":
                        animals.Add(new Cat(inputLine2[0], int.Parse(inputLine2[1]), inputLine2[2]));
                        break;
                    case "Dog":
                        animals.Add(new Dog(inputLine2[0], int.Parse(inputLine2[1]), inputLine2[2]));            
                        break;
                    case "Frog":
                        animals.Add(new Frog(inputLine2[0], int.Parse(inputLine2[1]), inputLine2[2]));
                        break;
                    case "Kitten":
                        animals.Add(new Kitten(inputLine2[0], int.Parse(inputLine2[1]), inputLine2[2]));
                        break;
                    case "Tomcat":
                        animals.Add(new Tomcat(inputLine2[0], int.Parse(inputLine2[1]), inputLine2[2]));
                        break;
                    default:
                        break;
                }
            }

            foreach (var item in animals)
            {
                Console.WriteLine(item.ToString());
            }

        }
    }
}
